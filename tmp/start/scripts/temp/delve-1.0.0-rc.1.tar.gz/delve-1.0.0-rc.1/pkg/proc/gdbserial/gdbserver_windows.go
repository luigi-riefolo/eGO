package gdbserial

import "syscall"

func backgroundSysProcAttr() *syscall.SysProcAttr {
	return nil
}
